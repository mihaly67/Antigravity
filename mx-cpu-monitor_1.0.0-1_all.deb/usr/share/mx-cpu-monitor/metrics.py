#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MX CPU Monitor - Rendszermutatók és szenzorok olvasása
Közvetlen /proc és /sys elérés külső függőségek nélkül.
"""

import os
import time
import glob

class SystemMetrics:
    def __init__(self):
        self.prev_stat = self._read_stat()
        self.prev_rapl = self._read_rapl()
        self.prev_time = time.time()
        self.cpu_model = self._detect_cpu_model()
        self.core_count, self.thread_count = self._detect_core_counts()
        self.cores = self.core_count
        self.threads = self.thread_count
        self.tdp = self._detect_tdp()

    def _detect_cpu_model(self):
        model = "Ismeretlen CPU"
        try:
            with open('/proc/cpuinfo', 'r') as f:
                for line in f:
                    if line.startswith('model name'):
                        model = line.split(':', 1)[1].strip()
                        break
        except Exception:
            pass
        return model

    def _detect_core_counts(self):
        threads = os.cpu_count() or 1
        cores_set = set()
        try:
            with open('/proc/cpuinfo', 'r') as f:
                curr_phys = None
                curr_core = None
                for line in f:
                    line = line.strip()
                    if line.startswith('physical id'):
                        curr_phys = line.split(':', 1)[1].strip()
                    elif line.startswith('core id'):
                        curr_core = line.split(':', 1)[1].strip()
                    if curr_phys is not None and curr_core is not None:
                        cores_set.add((curr_phys, curr_core))
                        curr_phys = None
                        curr_core = None
        except Exception:
            pass
        cores = len(cores_set) if cores_set else (threads // 2 if threads > 1 else 1)
        return cores, threads

    def _read_stat(self):
        data = {}
        try:
            with open('/proc/stat', 'r') as f:
                for line in f:
                    if line.startswith('cpu'):
                        parts = line.strip().split()
                        name = parts[0]
                        vals = [int(x) for x in parts[1:]]
                        # user, nice, system, idle, iowait, irq, softirq, steal
                        busy = vals[0] + vals[1] + vals[2]
                        if len(vals) > 5: busy += vals[5] # irq
                        if len(vals) > 6: busy += vals[6] # softirq
                        if len(vals) > 7: busy += vals[7] # steal
                        total = sum(vals)
                        data[name] = (busy, total)
        except Exception:
            pass
        return data

    def _read_rapl(self):
        rapl_files = glob.glob('/sys/class/powercap/intel-rapl/intel-rapl:*/energy_uj')
        total_energy = 0
        found = False
        for rf in rapl_files:
            try:
                with open(rf, 'r') as f:
                    total_energy += int(f.read().strip())
                    found = True
            except Exception:
                pass
        return total_energy if found else None

    def _detect_tdp(self):
        limit_files = glob.glob('/sys/class/powercap/intel-rapl/intel-rapl:*/constraint_0_power_limit_uw')
        for lf in limit_files:
            try:
                with open(lf, 'r') as f:
                    uw = int(f.read().strip())
                    if uw > 0:
                        return uw / 1e6
            except Exception:
                pass
        return 65.0

    def get_memory_info(self):
        total_kb = 0
        avail_kb = 0
        try:
            with open('/proc/meminfo', 'r') as f:
                for line in f:
                    if line.startswith('MemTotal:'):
                        total_kb = int(line.split()[1])
                    elif line.startswith('MemAvailable:'):
                        avail_kb = int(line.split()[1])
        except Exception:
            pass
        used_kb = max(0, total_kb - avail_kb)
        pct = (used_kb / total_kb * 100.0) if total_kb > 0 else 0.0
        return {
            'total_gb': total_kb / (1024.0 * 1024.0),
            'used_gb': used_kb / (1024.0 * 1024.0),
            'pct': pct
        }

    def update(self):
        curr_time = time.time()
        dt = curr_time - self.prev_time
        if dt <= 0.001:
            dt = 0.001
        self.prev_time = curr_time

        # CPU Terhelés számítás
        curr_stat = self._read_stat()
        loads = {}
        for k in curr_stat:
            if k in self.prev_stat:
                b1, t1 = self.prev_stat[k]
                b2, t2 = curr_stat[k]
                db = b2 - b1
                dtot = t2 - t1
                load = (db / dtot * 100.0) if dtot > 0 else 0.0
                loads[k] = max(0.0, min(100.0, load))
            else:
                loads[k] = 0.0
        self.prev_stat = curr_stat

        # Fogyasztás (RAPL / Becslés)
        curr_rapl = self._read_rapl()
        power_w = 0.0
        power_is_real = False
        if curr_rapl is not None and self.prev_rapl is not None and dt > 0:
            de = curr_rapl - self.prev_rapl
            if de >= 0:
                power_w = de / (dt * 1e6)
                power_is_real = True
        self.prev_rapl = curr_rapl

        tot_load = loads.get('cpu', 0.0)
        if not power_is_real:
            # Becslés a TDP és terhelés alapján (alapjárat: ~15-20% TDP)
            power_w = self.tdp * (0.15 + 0.85 * (tot_load / 100.0))

        # Órajelek magonként
        freqs = {}
        ncpu = self.thread_count
        for i in range(ncpu):
            p = f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_cur_freq'
            if os.path.exists(p):
                try:
                    with open(p, 'r') as f:
                        freqs[f'cpu{i}'] = int(f.read().strip()) / 1000.0 # MHz
                except Exception:
                    pass
        if not freqs:
            try:
                with open('/proc/cpuinfo', 'r') as f:
                    idx = 0
                    for line in f:
                        if line.startswith('cpu MHz'):
                            val = float(line.split(':', 1)[1].strip())
                            freqs[f'cpu{idx}'] = val
                            idx += 1
            except Exception:
                pass

        # Hőmérsékletek (CoreTemp, K10Temp, ACPI, Thermal Zones)
        pkg_temp = None
        core_temps = {}
        for h in glob.glob('/sys/class/hwmon/hwmon*'):
            for t_in in glob.glob(os.path.join(h, 'temp*_input')):
                try:
                    lbl_f = t_in.replace('_input', '_label')
                    lbl = ''
                    if os.path.exists(lbl_f):
                        with open(lbl_f, 'r') as f:
                            lbl = f.read().strip()
                    val = int(open(t_in).read().strip()) / 1000.0
                    if any(x in lbl for x in ['Package', 'Tdie', 'Tctl']):
                        pkg_temp = val
                    elif 'Core' in lbl:
                        core_temps[lbl] = val
                    elif pkg_temp is None:
                        pkg_temp = val
                except Exception:
                    pass

        if pkg_temp is None:
            # Fallback a thermal zone-okra
            for tz in glob.glob('/sys/class/thermal/thermal_zone*/temp'):
                try:
                    val = int(open(tz).read().strip()) / 1000.0
                    if 10.0 <= val <= 115.0:
                        pkg_temp = val
                        break
                except Exception:
                    pass

        mem = self.get_memory_info()

        return {
            'cpu_model': self.cpu_model,
            'cores': self.core_count,
            'threads': self.thread_count,
            'total_load': tot_load,
            'core_loads': [loads.get(f'cpu{i}', 0.0) for i in range(ncpu)],
            'frequencies': [freqs.get(f'cpu{i}', 0.0) for i in range(ncpu)],
            'power_w': power_w,
            'power_real': power_is_real,
            'tdp': self.tdp,
            'pkg_temp': pkg_temp or 0.0,
            'core_temps': core_temps,
            'memory': mem
        }
